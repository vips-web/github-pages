■概要
VIPSTARCOIN-cli.exe を GUI から実行するツールです。
VIPSTARCOIN 公式ツールです。


■環境
Windows: Windows 7 Sp1 以降
macOS: 10.10 Yosemite 以降


■履歴
2018/04/30 ver.1.0.0  公開
2018/04/30 ver.1.0.1  ANSI Escape Code を無視するように修正
2018/05/01 ver.1.0.2  「楽しさを、買おう。」VIPSTARCOIN の理念を表示するように修正


■使い方
0.macOS の場合はライブラリのインストールなどが終わり、
  VIPSTARCOIN-cli が正しく動作する状態にしておいてください。
  Windows では MiningHelper32.exe と MiningHelper64.exe が提供されます。
  64bit 環境の方は MiningHelper64.exe をご利用ください。
  以下の MiningHelper は適宜 MiningHelper32.exe または MiningHelper64.exe と読み替えてください。

1.MiningHelper を VIPSTARCOIN-cli.exe と同じ所に置きます。
2.VIPSTARCOIN-qt.exe を起動します。
3.MiningHelper を起動します。
4.ウォレットアドレスを入れます（２回目以降は記憶しています）。
5.[○CPU] の右側にある 同時起動スレッド数を設定します（1～4 程度が適切です）。
6.[Start]ボタンを押します。
7.[Log]タブにログが表示されます（1024行まで。超えると古い物から削除）
8.マイニングに成功すると[Found]タブに成功時のログが表示されます。
  （削除無し。未見の成功ログがある時「VIPSTAR COIN」表示）
9.「▽」を押すとタスクトレイ / ステータスバーに常駐します。
  （「もやし」待機中、「つるはし」マイニング中、「埋まっているVIPSTAR COIN」マイニング成功）
10.終了時の位置を記憶して次回起動時はそこに表示されます。


■外部ツールマイニング
スタートボタンの上にある [○GPU] を選択すると ccminer を使った GPU マイニングモード（ブラックマッペモード）になります。
このモードでは ccminer を使って GPU マイニングしますが、GPU に負荷が掛かるため破損する場合があります。
ccminer によって生じた一切の不利益および損害に対して、 このツールの制作者・提供者はその責任を負いません。
あくまで自己責任でご利用ください。 

動作環境
  GPU: NVIDIA 製 CUDA 9 対応
   OS: Windows のみ

ccminer には ccminer-x64.exe と ccminer.exe があります。
64bit 版 MiningHelper を使っている場合は ccminer-x64.exe を、32bit 版を使っている場合は ccminer.exe を MiningHelper と同じ場所に置いてください。
[○GPU] は ccminer-x64 または ccminer がある場合に選択可能になります。

ccminer は自動的に VIPSTARCOIN のウォレットアドレスを作成し、それを PC 版ウォレットに追加します。
マイニング結果は、追加されたウォレットアドレスに反映されます（ブラックマッペでは MiningHelper 上で設定されている Walette Address は無効です）。
そのため PC 版ウォレットの VIPSTARCOIN.conf を適切に設定しなければなりません。
以下は設定例です。

------------------------------
server=1 
rpcallowip=127.0.0.1
rpcport=31916 
rpcuser=user
rpcpassword=pass
------------------------------
※user, pass は任意の文字列です
※VIPSTARCOIN.conf はデフォルトの場合 C:\Users\ユーザー名\AppData\Roaming\VIPSTARCOIN\ にあります。

また [○GPU] の隣にある [▽] ボタンを押すと ccminer に渡す追加パラメータを指定できます。

cccminer のソースは下記にあります。
https://github.com/mghtthr/ccminer


■応用編
normal.png, mining.png, black.png というファイルを MiningHelper.exe と同じ場所に置くと背景が切り替わります。

サイズ: 500x300[px]
コントロール領域: 左上から325x300[px]
normal.png: 通常時の背景
mining.png: マイニング時の背景
black.png:  ブラックマッペモード
