﻿QRVips: VIPS QR Code Generator
Copyright (C) VIPSTAR Inc., 2018.
Created by ooo.

■概要 / About
QRVips は VIPSTARCOIN スキームに対応した QR コードを生成するアプリケーションです。



■動作環境 / Environment
Windows 7 Sp1 以降
macOS 10.10 Yosemite ～ 10.14 Mojave



■履歴 / History
2018/06/11 ver.1.0.0  公開
2018/06/16 ver.1.0.1  スケーリングが 100% 以上の場合に ComboBox が再描画されなくなる問題を修正。
                      Light スタイル時にカーソルなどが見づらい色になっていた問題を修正。
2018/06/20 ver.1.1.0  アイコンの背景（白い円）を非表示にできるように変更。
                      VIP21 の Amount 額が無効な数値の場合、問合せる前にエラーを出すように修正。
2018/07/10 ver.1.1.1  BIP21 では Amount が未指定でも QR コードを生成するように修正（VIP21は必要）
2018/08/19 ver.1.1.2  VIP21 は AmountExt, AmountType 両方を指定しないと生成されないように修正
                      Style を有料 Style に変更（残念ながら Cyber は廃止）



■インストール / How to installe
インストーラーは付属しません。
適切なフォルダに置いてください。



■使い方 / Usage
起動したら、右側の VIPSTARCOIN アドレスや送金額などを入力すると QR コードが生成されます。
また、中央やや下にあるアイコン表示部分でアイコンを選ぶと QR コード中央にアイコンが表示されます。
最下部にある「保存」 ボタンで保存できます。
保存ボタンの左側にあるドロップダウンでは画像サイズを選択できます。
「カスタム」を選ぶと自由なサイズで保存できますが、キャラクタ部分がぼやけるかも知れません。

QR コード表示部分に画像ファイルをドロップできます。
するとアイコン部分に登録され QR コード中央部に画像が表示されます。

ただし、ドロップされたファイル情報は保存されません！
次回起動時にはクリアされています。
ご注意ください。



■応用編 / Advanced usage
１．アプリケーションと同じ所に images という名前のフォルダを作ります。
２．images フォルダに画像ファイルを入れます。
３．images フォルダの画像がアイコンとして使えるようになります。



■VIP21 について / About VIP21
BIP21 を拡張した VIP21 に対応しています。
amountExt, amountType を指定すると、VIPS 以外の通貨で値を設定できます。

例）
<a href="vipstarcoin:VYLPUGaj6WzXTsbcyigAYGV7TNWgyAyNTx?amountExt=100&amountType=JPY">100円送る！</a>

上記の例では JPY ベースで値を設定しています。
リンクを踏んだときに JPY/VIPS のレートを取得し、そのレートで VIPS を設定します。
例えば 1[VIPS] = 0.0482819746[JPY] だった場合、100円は 2071.16632715[VIPS] として送金されます。
