pow_mining.batをテキストエディタで開いてVXXXXを自分のアドレスに変更
